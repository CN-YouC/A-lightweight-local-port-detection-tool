@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo 找不到 csc.exe，本机可能没有安装 .NET Framework 4.x。
    pause
    exit /b 1
)

"%CSC%" /nologo /target:winexe /codepage:65001 /optimize+ /platform:anycpu ^
 /out:"端口检测工具.exe" ^
 /win32manifest:"app.manifest" ^
 /r:System.dll /r:System.Core.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Management.dll ^
 "端口检测工具.cs"

if errorlevel 1 (
    echo.
    echo 编译失败。
    pause
    exit /b 1
)

echo.
echo 编译完成：端口检测工具.exe
pause
